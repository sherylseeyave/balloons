package com.example.poptheballoons;

import java.util.Random;

public class ColorShape {
    public static class Colors {
        String name;
        int color;
        public Colors(String name, int color) {
            this.name = name;
            this.color = color;
        }
    }
//    private String name;
//    private int color;
    private Colors currColor = null;
    private Colors[] colorList;

    public ColorShape() {
        colorList = new Colors[]{new Colors("red", android.graphics.Color.RED),
                new Colors("orange", android.graphics.Color.parseColor("#FFA500")),
                new Colors("yellow", android.graphics.Color.YELLOW),
                new Colors("green", android.graphics.Color.GREEN),
                new Colors("blue", android.graphics.Color.BLUE),
                new Colors("purple", android.graphics.Color.parseColor("#800080")),
                new Colors("white", android.graphics.Color.WHITE)};
        setRandomColor();
    }

    public String getName() {return currColor.name;}
    public int getColor() {return currColor.color;}

//    public void setName(String name) {this.name = name;}
//    public void setColor(int color) {this.color = color;}

    public void setRandomColor() {
        Random rand = new Random();
        this.currColor = colorList[rand.nextInt(colorList.length)];
    }
}
