package com.example.poptheballoons;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;

public class Square extends Shape{
    public Square(Context context, int screenHeight, int screenWidth) {
        super(context, screenHeight, screenWidth);

    }

    @Override
    void drawBalloon(Canvas canvas) {
        System.out.println(x);
        rectF = new RectF(x, y - size, x + size, y);
        Paint paint = new Paint();
        paint.setColor(color);
        canvas.drawRect(rectF, paint);
    }

    @Override
    float getTop() {
        return 0;
    }

    @Override
    boolean getShape() {
        return false;
    }

}
