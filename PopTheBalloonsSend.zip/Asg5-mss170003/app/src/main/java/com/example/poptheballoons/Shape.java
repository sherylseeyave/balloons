package com.example.poptheballoons;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.DisplayMetrics;

import java.util.Random;

public abstract class Shape {
    /*
        size - balloon size between 32dp and 64dp
        color - integer color value
        x - random x coordinate in the canvas
        y - random y coordinate in the canvas
     */
    int size, color, velocity;
    float x, y;
    RectF rectF;
    ColorShape colorShape = new ColorShape();
    public Shape(Context context, int screenHeight, int screenWidth) {
        Random rand = new Random();
        int randSize = rand.nextInt(33) + 32;
        this.size = dpToPx(context, randSize);
        this.x = rand.nextInt(screenWidth - this.size);
        this.y = screenHeight + size;
        this.color = colorShape.getColor();
        rectF = new RectF(x, y - size, x + size, y); // left, top , right, bottom
    }

    abstract void drawBalloon(Canvas canvas);
    abstract  float getTop();
    abstract boolean getShape();

    public void setX(int x) {
        this.x = x;
    }
    /*
     * Convert pixels to dp
     */
    public static int pxToDp(Context context, int px) {
        DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
        int dp = Math.round(px / (displayMetrics.xdpi / DisplayMetrics.DENSITY_DEFAULT));
        return dp;
    }

    /*
     * Convert dp to pixels
     */
    public static int dpToPx(Context context, int dp) {
        float density = context.getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }

}
