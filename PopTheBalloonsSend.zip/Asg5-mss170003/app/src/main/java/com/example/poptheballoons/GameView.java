package com.example.poptheballoons;

import android.content.Context;
import android.os.Handler;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;


import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

public class GameView extends View {
    Handler h;
    int frameRate, state = 0, canvasHeight, canvasWidth, numberOfBalloons;
    List<Shape> balloons;

    // Current game shape and color
    boolean gameShape;
    int gameColor;
    TextView scoreTV, timerTV, resultTV;
    LinearLayout resultView;
    Button viewScoreButton;

    public GameView(Context context) {
        super(context);
        init(context);
    }

    public GameView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        init(context);

    }

    public void init(Context context) {
        h = new Handler();
        frameRate = 1;
        balloons = new ArrayList<>();
    }

    public void setGame(boolean shape, int color) {
        this.gameShape = shape;
        this.gameColor = color;
    }

    public void setTextView(TextView score, TextView timer) {
        this.scoreTV = score;
        this.timerTV = timer;
    }

    public void setResultView(LinearLayout resultView, TextView result, Button viewScore) {
        this.resultView = resultView;
        this.resultTV = result;
        this.viewScoreButton = viewScore;
    }
//
//    @Override
//    public boolean onTouchEvent(MotionEvent event) {
//        return super.onTouchEvent(event);
//    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        canvasHeight = canvas.getHeight();
        canvasWidth = canvas.getWidth();
        Random rand = new Random();

        // Add a random number of random balloons to the list
        if (state == 0) {
            numberOfBalloons = rand.nextInt(7) + 6;
            int split = canvasWidth / numberOfBalloons;
            createBalloons(split, numberOfBalloons, rand);
            state++;
        }

        // Balloons do not overlay
//        for(Shape balloon: balloons) {
//            if(state != 0) {
//
//            }
//        }



        for(Shape balloon: balloons) {
            balloon.drawBalloon(canvas);
        }

        h.postDelayed(r, 10);
    }

    /****************************************************************************
     * Create a new thread that will let us time the rate of the ball.  It
     * causes the screen to be redrawn.
     ****************************************************************************/
    private Runnable r = new Runnable() {
        @Override
        public void run()
        {
            invalidate();
        }
    };


    public void createBalloons(int split, int num, Random rand) {
        for(int i = 0; i < num; i++) {
            if(rand.nextInt(2) == 1) {
                balloons.add(new Circle(getContext(), canvasHeight, canvasWidth));
            } else {
                balloons.add(new Square(getContext(), canvasHeight, canvasWidth));
            }
            balloons.get(i).setX((split*(i+1)) -  (split/2));
        }
    }
}
