package com.example.poptheballoons;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;

import java.sql.SQLOutput;

public class Circle extends Shape {
    public Circle(Context context, int screenHeight, int screenWidth) {
        super(context, screenHeight, screenWidth);
    }

    @Override
    void drawBalloon(Canvas canvas) {
        //rect = new Rect((int) x, (int) y - size, (int) x + size, (int) y);
        Paint paint = new Paint();
        paint.setColor(color);
        System.out.println(x);
        canvas.drawCircle(x, y, size / 2, paint); // (x center, y center, radius, color)
    }

    @Override
    float getTop() {
        return 0;
    }

    @Override
    boolean getShape() {
        return false;
    }


}
