package com.example.poptheballoons;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    Button startButton;
    TextView instructionText;
    ColorShape color = new ColorShape();
    boolean shape;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        startButton = findViewById(R.id.startButton);
        instructionText = findViewById(R.id.instructionText);

        Random rand = new Random();
        //color = color.getRandomColor(); // set color
        shape = rand.nextInt(2) == 1; // set shape

        // Circle
        if(shape) {
            instructionText.setText("Pop only " + color.getName() + " circles");
            GradientDrawable gradientDrawable = new GradientDrawable();
            gradientDrawable.setShape(GradientDrawable.OVAL);
            gradientDrawable.setColor(color.getColor());
            gradientDrawable.setStroke(2, Color.BLACK);             // Set the stroke width and color
        }
        // Square
        else {
            instructionText.setText("Pop only " + color.getName() + " squares");
            GradientDrawable gradientDrawable = new GradientDrawable();
            gradientDrawable.setShape(GradientDrawable.RECTANGLE);
            gradientDrawable.setColor(color.getColor());
            gradientDrawable.setStroke(2, Color.BLACK);             // Set the stroke width and color
        }

        System.out.println(color.getColor());
        System.out.println(color.getName());
        System.out.println(shape);

        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, GameActivity.class);
                intent.putExtra("color", color.getColor());
                intent.putExtra("shape", shape);
                startActivity(intent);
            }
        });
    }
}